﻿using Anon.Dataxml;
using Anon.Helpers;
using Anon.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Anon
{
    public class Program
    {
        
        //Export export = new Export();
        


        public static void Main(string[] args)
        {
            Replacer replace = new Replacer();
            Searchers s = new Searchers();

            DeserClass.Deserialize();
            replace.AttributeReplacer("Name");
            s.AttributeSearcher("name");
            s.TableConstraintDefintions("name");
            s.Components("Name");
            s.PCConfugrationmodel("Name");













        }
    }
}
