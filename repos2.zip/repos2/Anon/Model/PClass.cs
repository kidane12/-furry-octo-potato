﻿using Anon.Dataxml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Anon.Model
{
    class PClass
    {
        List<ExportAttributeTypesEcoResAttributeType> LAttributes;
        Export speakerModel;

        public Export SpeakerModel()
        {
            XmlSerializer s = new XmlSerializer(typeof(Export));

            using (var sr = new StringReader(XmlModels.SpeakerSolution))
            {
                speakerModel = (Export)s.Deserialize(sr);

                return speakerModel;
            }

        }

        public List<ExportAttributeTypesEcoResAttributeType> Attributes()
        {

            return SpeakerModel().AttributeTypes.ToList();
        }
    }
}
