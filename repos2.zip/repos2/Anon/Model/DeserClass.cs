﻿using Anon.Dataxml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Anon.Model
{
   public static class DeserClass
    {

        public static List<ExportAttributeTypesEcoResAttributeType> LAttributes;
        public static List<ExportTableConstraintDefintionsPCGlobalTableConstraintDefinition> TTableConstraintDefintions;
        public static List<ExportComponentsPCClass> CComponents;
        public static List<ExportPCProductConfigurationModel> EExportPCProductConfigurationModel;
        public static Export speakerModel;
        public static Export CopyspeakerModel;
        static XmlSerializer s;
        public static void Deserialize()
        {
            s = new XmlSerializer(typeof(Export));
            //XmlSerializer ss = new XmlSerializer(typeof(Export));

            using (var sr = new StringReader(XmlModels.SpeakerSolution))
            {
                try
                {
                    speakerModel = (Export)s.Deserialize(sr);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Can't be Serialized", e);
                }

                LAttributes = speakerModel.AttributeTypes.ToList();
                TTableConstraintDefintions = speakerModel.TableConstraintDefintions.ToList();
                CComponents = speakerModel.Components.ToList();
                EExportPCProductConfigurationModel = speakerModel.PCProductConfigurationModel.ToList();
            }       }

        public static void Serialize()
        {
            XmlSerializer ss = new XmlSerializer(typeof(Export));

            using (var ssr = new FileStream("C:\\Users\\PC\\Desktop\\AnnSpeakerSolution1.xml", FileMode.OpenOrCreate))
            {
                try
                {
                    ss.Serialize(ssr, speakerModel);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Can't be Serialized", e);
                }

            }

        }


    }
}
