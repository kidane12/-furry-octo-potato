﻿using Anon.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anon.Helpers
{
    class Replacer
    {

        List<attribute> Anonattributes = new List<attribute>();

        public void AttributeReplacer(string name)
        {
            attribute AnAtrib = new attribute("", "X", "", "", "", "");

            foreach (var atr in DeserClass.LAttributes)
            {

                AnAtrib.OName = atr.Name;
                AnAtrib.NName += "X";
                atr.Name = AnAtrib.NName;
                Anonattributes.Add(AnAtrib);
                if (atr.IsEnumeration == "1")
                {
                    foreach (var EnumAttributeType in atr.EcoResEnumerationAttributeTypeValue.ToList())
                    {
                        Console.WriteLine("OrdinalNumber is {0}, EnumerationValue is {1}, SolverValue is {2}",
                            EnumAttributeType.OrdinalNumber, EnumAttributeType.EnumerationValue, EnumAttributeType.SolverValue);

                        foreach (var x in EnumAttributeType.EcoResTextValueTranslation.ToList())
                        {
                            Console.WriteLine(x.TextValue, x.Language);
                        }
                        //Console.WriteLine(atrr.Upper);

                    }
                }
                if (atr.HasBounds == "1")
                {
                    foreach (var bound in atr.EcoResBoundedAttributeTypeValue.ToList())
                    {
                        AnAtrib.OUBound = bound.Upper;
                        AnAtrib.NUBound += "*";
                        bound.Upper = AnAtrib.NUBound;

                        AnAtrib.OLBound = bound.Lower;
                        AnAtrib.NLBound += "*";
                        bound.Lower = AnAtrib.NLBound;


                    }
                }

            }
            DeserClass.Serialize();

        }
    }
}
