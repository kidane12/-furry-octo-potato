﻿using AnonymizationPCM.Dataxml;
using System;
using System.IO;
using System.Xml.Serialization;

namespace AnonymizationPCM
{
    class Program
    {
        //private static string myRoot;
        

        //PCExpressionConstraint Speakersolution = new PCExpressionConstraint();
        static void Main(string[] args)
        { 
            XmlSerializer s = new XmlSerializer(typeof(Export));

            using (var sr = new StringReader(XmlModels.SpeakerSolution))
            {
                Export speakerModel = (Export) s.Deserialize(sr);
                Console.Write(speakerModel.PCProductConfigurationModel);
                Console.WriteLine("2");
            }
            
        }
    }
}
