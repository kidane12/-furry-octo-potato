﻿namespace TrackerUI
{
    partial class CreateTournamentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Createtournamentlabel = new System.Windows.Forms.Label();
            this.Tournamentvalue = new System.Windows.Forms.TextBox();
            this.TornamrentLabel = new System.Windows.Forms.Label();
            this.Entryfeevalue = new System.Windows.Forms.TextBox();
            this.Entriefeelabel = new System.Windows.Forms.Label();
            this.SelectteamDropdown = new System.Windows.Forms.ComboBox();
            this.Selectteamlabel = new System.Windows.Forms.Label();
            this.Createnewteamlink = new System.Windows.Forms.LinkLabel();
            this.AddTeam = new System.Windows.Forms.Button();
            this.CreatePrizebutton = new System.Windows.Forms.Button();
            this.TournamentPlayerslistBox = new System.Windows.Forms.ListBox();
            this.TournamentPlayerslabel = new System.Windows.Forms.Label();
            this.DeleteSelectedPlayersbutton = new System.Windows.Forms.Button();
            this.DeleteSelectedPrizesbutton1 = new System.Windows.Forms.Button();
            this.Prizedlabel = new System.Windows.Forms.Label();
            this.PrizelistlistBox1 = new System.Windows.Forms.ListBox();
            this.CreateTournamentbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Createtournamentlabel
            // 
            this.Createtournamentlabel.AutoSize = true;
            this.Createtournamentlabel.Location = new System.Drawing.Point(5, 29);
            this.Createtournamentlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Createtournamentlabel.Name = "Createtournamentlabel";
            this.Createtournamentlabel.Size = new System.Drawing.Size(75, 25);
            this.Createtournamentlabel.TabIndex = 3;
            this.Createtournamentlabel.Text = "Round";
            // 
            // Tournamentvalue
            // 
            this.Tournamentvalue.Location = new System.Drawing.Point(16, 112);
            this.Tournamentvalue.Name = "Tournamentvalue";
            this.Tournamentvalue.Size = new System.Drawing.Size(339, 31);
            this.Tournamentvalue.TabIndex = 10;
            this.Tournamentvalue.TextChanged += new System.EventHandler(this.ScoretextBox_TextChanged);
            // 
            // TornamrentLabel
            // 
            this.TornamrentLabel.AutoSize = true;
            this.TornamrentLabel.Location = new System.Drawing.Point(11, 84);
            this.TornamrentLabel.Name = "TornamrentLabel";
            this.TornamrentLabel.Size = new System.Drawing.Size(189, 25);
            this.TornamrentLabel.TabIndex = 9;
            this.TornamrentLabel.Text = "Tournament Name";
            this.TornamrentLabel.Click += new System.EventHandler(this.TeamOneScoreLabel_Click);
            // 
            // Entryfeevalue
            // 
            this.Entryfeevalue.Location = new System.Drawing.Point(26, 211);
            this.Entryfeevalue.Name = "Entryfeevalue";
            this.Entryfeevalue.Size = new System.Drawing.Size(329, 31);
            this.Entryfeevalue.TabIndex = 12;
            this.Entryfeevalue.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // Entriefeelabel
            // 
            this.Entriefeelabel.AutoSize = true;
            this.Entriefeelabel.Location = new System.Drawing.Point(21, 183);
            this.Entriefeelabel.Name = "Entriefeelabel";
            this.Entriefeelabel.Size = new System.Drawing.Size(92, 25);
            this.Entriefeelabel.TabIndex = 11;
            this.Entriefeelabel.Text = "Entryfee";
            this.Entriefeelabel.Click += new System.EventHandler(this.Label1_Click);
            // 
            // SelectteamDropdown
            // 
            this.SelectteamDropdown.FormattingEnabled = true;
            this.SelectteamDropdown.Location = new System.Drawing.Point(30, 309);
            this.SelectteamDropdown.Name = "SelectteamDropdown";
            this.SelectteamDropdown.Size = new System.Drawing.Size(325, 33);
            this.SelectteamDropdown.TabIndex = 14;
            // 
            // Selectteamlabel
            // 
            this.Selectteamlabel.AutoSize = true;
            this.Selectteamlabel.Location = new System.Drawing.Point(25, 267);
            this.Selectteamlabel.Name = "Selectteamlabel";
            this.Selectteamlabel.Size = new System.Drawing.Size(126, 25);
            this.Selectteamlabel.TabIndex = 13;
            this.Selectteamlabel.Text = "SelectTeam";
            // 
            // Createnewteamlink
            // 
            this.Createnewteamlink.AutoSize = true;
            this.Createnewteamlink.Location = new System.Drawing.Point(221, 267);
            this.Createnewteamlink.Name = "Createnewteamlink";
            this.Createnewteamlink.Size = new System.Drawing.Size(117, 25);
            this.Createnewteamlink.TabIndex = 15;
            this.Createnewteamlink.TabStop = true;
            this.Createnewteamlink.Text = "create new";
            // 
            // AddTeam
            // 
            this.AddTeam.Location = new System.Drawing.Point(97, 348);
            this.AddTeam.Name = "AddTeam";
            this.AddTeam.Size = new System.Drawing.Size(182, 39);
            this.AddTeam.TabIndex = 16;
            this.AddTeam.Text = "Add team";
            this.AddTeam.UseVisualStyleBackColor = true;
            // 
            // CreatePrizebutton
            // 
            this.CreatePrizebutton.Location = new System.Drawing.Point(97, 419);
            this.CreatePrizebutton.Name = "CreatePrizebutton";
            this.CreatePrizebutton.Size = new System.Drawing.Size(182, 39);
            this.CreatePrizebutton.TabIndex = 17;
            this.CreatePrizebutton.Text = "Create Prize";
            this.CreatePrizebutton.UseVisualStyleBackColor = true;
            // 
            // TournamentPlayerslistBox
            // 
            this.TournamentPlayerslistBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TournamentPlayerslistBox.FormattingEnabled = true;
            this.TournamentPlayerslistBox.ItemHeight = 25;
            this.TournamentPlayerslistBox.Location = new System.Drawing.Point(379, 112);
            this.TournamentPlayerslistBox.Name = "TournamentPlayerslistBox";
            this.TournamentPlayerslistBox.Size = new System.Drawing.Size(314, 127);
            this.TournamentPlayerslistBox.TabIndex = 18;
            // 
            // TournamentPlayerslabel
            // 
            this.TournamentPlayerslabel.AutoSize = true;
            this.TournamentPlayerslabel.Location = new System.Drawing.Point(444, 84);
            this.TournamentPlayerslabel.Name = "TournamentPlayerslabel";
            this.TournamentPlayerslabel.Size = new System.Drawing.Size(144, 25);
            this.TournamentPlayerslabel.TabIndex = 19;
            this.TournamentPlayerslabel.Text = "Team/Players";
            // 
            // DeleteSelectedPlayersbutton
            // 
            this.DeleteSelectedPlayersbutton.Location = new System.Drawing.Point(718, 112);
            this.DeleteSelectedPlayersbutton.Name = "DeleteSelectedPlayersbutton";
            this.DeleteSelectedPlayersbutton.Size = new System.Drawing.Size(138, 65);
            this.DeleteSelectedPlayersbutton.TabIndex = 20;
            this.DeleteSelectedPlayersbutton.Text = "DeleteSelectedPlayers";
            this.DeleteSelectedPlayersbutton.UseVisualStyleBackColor = true;
            // 
            // DeleteSelectedPrizesbutton1
            // 
            this.DeleteSelectedPrizesbutton1.Location = new System.Drawing.Point(727, 348);
            this.DeleteSelectedPrizesbutton1.Name = "DeleteSelectedPrizesbutton1";
            this.DeleteSelectedPrizesbutton1.Size = new System.Drawing.Size(138, 65);
            this.DeleteSelectedPrizesbutton1.TabIndex = 23;
            this.DeleteSelectedPrizesbutton1.Text = "DeleteSelectedPrizes";
            this.DeleteSelectedPrizesbutton1.UseVisualStyleBackColor = true;
            // 
            // Prizedlabel
            // 
            this.Prizedlabel.AutoSize = true;
            this.Prizedlabel.Location = new System.Drawing.Point(457, 267);
            this.Prizedlabel.Name = "Prizedlabel";
            this.Prizedlabel.Size = new System.Drawing.Size(144, 25);
            this.Prizedlabel.TabIndex = 22;
            this.Prizedlabel.Text = "Team/Players";
            // 
            // PrizelistlistBox1
            // 
            this.PrizelistlistBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PrizelistlistBox1.FormattingEnabled = true;
            this.PrizelistlistBox1.ItemHeight = 25;
            this.PrizelistlistBox1.Location = new System.Drawing.Point(388, 306);
            this.PrizelistlistBox1.Name = "PrizelistlistBox1";
            this.PrizelistlistBox1.Size = new System.Drawing.Size(314, 152);
            this.PrizelistlistBox1.TabIndex = 21;
            // 
            // CreateTournamentbutton
            // 
            this.CreateTournamentbutton.Location = new System.Drawing.Point(274, 486);
            this.CreateTournamentbutton.Name = "CreateTournamentbutton";
            this.CreateTournamentbutton.Size = new System.Drawing.Size(182, 39);
            this.CreateTournamentbutton.TabIndex = 24;
            this.CreateTournamentbutton.Text = "CreateTournament";
            this.CreateTournamentbutton.UseVisualStyleBackColor = true;
            // 
            // CreateTournamentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.CreateTournamentbutton);
            this.Controls.Add(this.DeleteSelectedPrizesbutton1);
            this.Controls.Add(this.Prizedlabel);
            this.Controls.Add(this.PrizelistlistBox1);
            this.Controls.Add(this.DeleteSelectedPlayersbutton);
            this.Controls.Add(this.TournamentPlayerslabel);
            this.Controls.Add(this.TournamentPlayerslistBox);
            this.Controls.Add(this.CreatePrizebutton);
            this.Controls.Add(this.AddTeam);
            this.Controls.Add(this.Createnewteamlink);
            this.Controls.Add(this.SelectteamDropdown);
            this.Controls.Add(this.Selectteamlabel);
            this.Controls.Add(this.Entryfeevalue);
            this.Controls.Add(this.Entriefeelabel);
            this.Controls.Add(this.Tournamentvalue);
            this.Controls.Add(this.TornamrentLabel);
            this.Controls.Add(this.Createtournamentlabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "CreateTournamentForm";
            this.Text = "CreateTournamentForm";
            this.Load += new System.EventHandler(this.CreateTournamentForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Createtournamentlabel;
        private System.Windows.Forms.TextBox Tournamentvalue;
        private System.Windows.Forms.Label TornamrentLabel;
        private System.Windows.Forms.TextBox Entryfeevalue;
        private System.Windows.Forms.Label Entriefeelabel;
        private System.Windows.Forms.ComboBox SelectteamDropdown;
        private System.Windows.Forms.Label Selectteamlabel;
        private System.Windows.Forms.LinkLabel Createnewteamlink;
        private System.Windows.Forms.Button AddTeam;
        private System.Windows.Forms.Button CreatePrizebutton;
        private System.Windows.Forms.ListBox TournamentPlayerslistBox;
        private System.Windows.Forms.Label TournamentPlayerslabel;
        private System.Windows.Forms.Button DeleteSelectedPlayersbutton;
        private System.Windows.Forms.Button DeleteSelectedPrizesbutton1;
        private System.Windows.Forms.Label Prizedlabel;
        private System.Windows.Forms.ListBox PrizelistlistBox1;
        private System.Windows.Forms.Button CreateTournamentbutton;
    }
}