﻿namespace TrackerUI
{
    partial class CreatePrize
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TeamnameLabel = new System.Windows.Forms.Label();
            this.PrizeNamelabel = new System.Windows.Forms.Label();
            this.PrizeNumeberlabel = new System.Windows.Forms.Label();
            this.PrizeAmountlabel = new System.Windows.Forms.Label();
            this.PrizePercentagelabel = new System.Windows.Forms.Label();
            this.PrizeNameValue = new System.Windows.Forms.TextBox();
            this.PrizeNumberValue = new System.Windows.Forms.TextBox();
            this.PrizeAmountValue = new System.Windows.Forms.TextBox();
            this.PrizePercentagevalue = new System.Windows.Forms.TextBox();
            this.CreatePrizebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TeamnameLabel
            // 
            this.TeamnameLabel.AutoSize = true;
            this.TeamnameLabel.Location = new System.Drawing.Point(183, 9);
            this.TeamnameLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TeamnameLabel.Name = "TeamnameLabel";
            this.TeamnameLabel.Size = new System.Drawing.Size(119, 25);
            this.TeamnameLabel.TabIndex = 13;
            this.TeamnameLabel.Text = "Teamname";
            // 
            // PrizeNamelabel
            // 
            this.PrizeNamelabel.AutoSize = true;
            this.PrizeNamelabel.Location = new System.Drawing.Point(15, 141);
            this.PrizeNamelabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizeNamelabel.Name = "PrizeNamelabel";
            this.PrizeNamelabel.Size = new System.Drawing.Size(117, 25);
            this.PrizeNamelabel.TabIndex = 14;
            this.PrizeNamelabel.Text = "PrizeName";
            // 
            // PrizeNumeberlabel
            // 
            this.PrizeNumeberlabel.AutoSize = true;
            this.PrizeNumeberlabel.Location = new System.Drawing.Point(15, 79);
            this.PrizeNumeberlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizeNumeberlabel.Name = "PrizeNumeberlabel";
            this.PrizeNumeberlabel.Size = new System.Drawing.Size(148, 25);
            this.PrizeNumeberlabel.TabIndex = 15;
            this.PrizeNumeberlabel.Text = "PrizeNumeber";
            // 
            // PrizeAmountlabel
            // 
            this.PrizeAmountlabel.AutoSize = true;
            this.PrizeAmountlabel.Location = new System.Drawing.Point(15, 198);
            this.PrizeAmountlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizeAmountlabel.Name = "PrizeAmountlabel";
            this.PrizeAmountlabel.Size = new System.Drawing.Size(134, 25);
            this.PrizeAmountlabel.TabIndex = 16;
            this.PrizeAmountlabel.Text = "PrizeAmount";
            // 
            // PrizePercentagelabel
            // 
            this.PrizePercentagelabel.AutoSize = true;
            this.PrizePercentagelabel.Location = new System.Drawing.Point(15, 278);
            this.PrizePercentagelabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizePercentagelabel.Name = "PrizePercentagelabel";
            this.PrizePercentagelabel.Size = new System.Drawing.Size(171, 25);
            this.PrizePercentagelabel.TabIndex = 17;
            this.PrizePercentagelabel.Text = "PrizePercentage";
            // 
            // PrizeNameValue
            // 
            this.PrizeNameValue.Location = new System.Drawing.Point(188, 135);
            this.PrizeNameValue.Name = "PrizeNameValue";
            this.PrizeNameValue.Size = new System.Drawing.Size(339, 31);
            this.PrizeNameValue.TabIndex = 18;
            // 
            // PrizeNumberValue
            // 
            this.PrizeNumberValue.Location = new System.Drawing.Point(188, 79);
            this.PrizeNumberValue.Name = "PrizeNumberValue";
            this.PrizeNumberValue.Size = new System.Drawing.Size(339, 31);
            this.PrizeNumberValue.TabIndex = 19;
            // 
            // PrizeAmountValue
            // 
            this.PrizeAmountValue.Location = new System.Drawing.Point(188, 198);
            this.PrizeAmountValue.Name = "PrizeAmountValue";
            this.PrizeAmountValue.Size = new System.Drawing.Size(339, 31);
            this.PrizeAmountValue.TabIndex = 20;
            this.PrizeAmountValue.Text = "0";
            // 
            // PrizePercentagevalue
            // 
            this.PrizePercentagevalue.Location = new System.Drawing.Point(188, 275);
            this.PrizePercentagevalue.Name = "PrizePercentagevalue";
            this.PrizePercentagevalue.Size = new System.Drawing.Size(339, 31);
            this.PrizePercentagevalue.TabIndex = 21;
            this.PrizePercentagevalue.Text = "0";
            // 
            // CreatePrizebutton
            // 
            this.CreatePrizebutton.Location = new System.Drawing.Point(163, 346);
            this.CreatePrizebutton.Name = "CreatePrizebutton";
            this.CreatePrizebutton.Size = new System.Drawing.Size(182, 39);
            this.CreatePrizebutton.TabIndex = 22;
            this.CreatePrizebutton.Text = "CreatePrize";
            this.CreatePrizebutton.UseVisualStyleBackColor = true;
            this.CreatePrizebutton.Click += new System.EventHandler(this.CreatePrizebutton_Click);
            // 
            // CreatePrize
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 749);
            this.Controls.Add(this.CreatePrizebutton);
            this.Controls.Add(this.PrizePercentagevalue);
            this.Controls.Add(this.PrizeAmountValue);
            this.Controls.Add(this.PrizeNumberValue);
            this.Controls.Add(this.PrizeNameValue);
            this.Controls.Add(this.PrizePercentagelabel);
            this.Controls.Add(this.PrizeAmountlabel);
            this.Controls.Add(this.PrizeNumeberlabel);
            this.Controls.Add(this.PrizeNamelabel);
            this.Controls.Add(this.TeamnameLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "CreatePrize";
            this.Text = "CreatePrize";
            this.Load += new System.EventHandler(this.CreatePrize_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TeamnameLabel;
        private System.Windows.Forms.Label PrizeNamelabel;
        private System.Windows.Forms.Label PrizeNumeberlabel;
        private System.Windows.Forms.Label PrizeAmountlabel;
        private System.Windows.Forms.Label PrizePercentagelabel;
        private System.Windows.Forms.TextBox PrizeNameValue;
        private System.Windows.Forms.TextBox PrizeNumberValue;
        private System.Windows.Forms.TextBox PrizeAmountValue;
        private System.Windows.Forms.TextBox PrizePercentagevalue;
        private System.Windows.Forms.Button CreatePrizebutton;
    }
}