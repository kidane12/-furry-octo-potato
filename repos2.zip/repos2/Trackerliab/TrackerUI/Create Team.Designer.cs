﻿namespace TrackerUI
{
    partial class Create_Team
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TeamNameValue = new System.Windows.Forms.TextBox();
            this.TeamnameLabel = new System.Windows.Forms.Label();
            this.Createteamlabel = new System.Windows.Forms.Label();
            this.AddMember = new System.Windows.Forms.Button();
            this.SelectteammenberDropdown = new System.Windows.Forms.ComboBox();
            this.SelectteamMemberlabel = new System.Windows.Forms.Label();
            this.AddNewMembergroupBox = new System.Windows.Forms.GroupBox();
            this.CreateMemberbutton = new System.Windows.Forms.Button();
            this.CellPhoneValue = new System.Windows.Forms.TextBox();
            this.CellPhonelabel = new System.Windows.Forms.Label();
            this.Emailvalue = new System.Windows.Forms.TextBox();
            this.Emaillabel = new System.Windows.Forms.Label();
            this.LastNameValue = new System.Windows.Forms.TextBox();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.FirstNameValue = new System.Windows.Forms.TextBox();
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.TeamMemberslistBox = new System.Windows.Forms.ListBox();
            this.DeleteSelectedMemberbutton = new System.Windows.Forms.Button();
            this.CreateTeambutton = new System.Windows.Forms.Button();
            this.AddNewMembergroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // TeamNameValue
            // 
            this.TeamNameValue.Location = new System.Drawing.Point(17, 92);
            this.TeamNameValue.Name = "TeamNameValue";
            this.TeamNameValue.Size = new System.Drawing.Size(339, 31);
            this.TeamNameValue.TabIndex = 13;
            // 
            // TeamnameLabel
            // 
            this.TeamnameLabel.AutoSize = true;
            this.TeamnameLabel.Location = new System.Drawing.Point(12, 64);
            this.TeamnameLabel.Name = "TeamnameLabel";
            this.TeamnameLabel.Size = new System.Drawing.Size(119, 25);
            this.TeamnameLabel.TabIndex = 12;
            this.TeamnameLabel.Text = "Teamname";
            // 
            // Createteamlabel
            // 
            this.Createteamlabel.AutoSize = true;
            this.Createteamlabel.Location = new System.Drawing.Point(15, 9);
            this.Createteamlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Createteamlabel.Name = "Createteamlabel";
            this.Createteamlabel.Size = new System.Drawing.Size(123, 25);
            this.Createteamlabel.TabIndex = 11;
            this.Createteamlabel.Text = "Createteam";
            // 
            // AddMember
            // 
            this.AddMember.Location = new System.Drawing.Point(84, 225);
            this.AddMember.Name = "AddMember";
            this.AddMember.Size = new System.Drawing.Size(182, 39);
            this.AddMember.TabIndex = 19;
            this.AddMember.Text = "AddMember";
            this.AddMember.UseVisualStyleBackColor = true;
            // 
            // SelectteammenberDropdown
            // 
            this.SelectteammenberDropdown.FormattingEnabled = true;
            this.SelectteammenberDropdown.Location = new System.Drawing.Point(17, 186);
            this.SelectteammenberDropdown.Name = "SelectteammenberDropdown";
            this.SelectteammenberDropdown.Size = new System.Drawing.Size(325, 33);
            this.SelectteammenberDropdown.TabIndex = 18;
            // 
            // SelectteamMemberlabel
            // 
            this.SelectteamMemberlabel.AutoSize = true;
            this.SelectteamMemberlabel.Location = new System.Drawing.Point(12, 144);
            this.SelectteamMemberlabel.Name = "SelectteamMemberlabel";
            this.SelectteamMemberlabel.Size = new System.Drawing.Size(197, 25);
            this.SelectteamMemberlabel.TabIndex = 17;
            this.SelectteamMemberlabel.Text = "SelectteamMember";
            // 
            // AddNewMembergroupBox
            // 
            this.AddNewMembergroupBox.Controls.Add(this.CreateMemberbutton);
            this.AddNewMembergroupBox.Controls.Add(this.CellPhoneValue);
            this.AddNewMembergroupBox.Controls.Add(this.CellPhonelabel);
            this.AddNewMembergroupBox.Controls.Add(this.Emailvalue);
            this.AddNewMembergroupBox.Controls.Add(this.Emaillabel);
            this.AddNewMembergroupBox.Controls.Add(this.LastNameValue);
            this.AddNewMembergroupBox.Controls.Add(this.LastNameLabel);
            this.AddNewMembergroupBox.Controls.Add(this.FirstNameValue);
            this.AddNewMembergroupBox.Controls.Add(this.FirstNameLabel);
            this.AddNewMembergroupBox.Location = new System.Drawing.Point(8, 287);
            this.AddNewMembergroupBox.Name = "AddNewMembergroupBox";
            this.AddNewMembergroupBox.Size = new System.Drawing.Size(334, 251);
            this.AddNewMembergroupBox.TabIndex = 20;
            this.AddNewMembergroupBox.TabStop = false;
            this.AddNewMembergroupBox.Text = "Add New Member";
            // 
            // CreateMemberbutton
            // 
            this.CreateMemberbutton.Location = new System.Drawing.Point(76, 196);
            this.CreateMemberbutton.Name = "CreateMemberbutton";
            this.CreateMemberbutton.Size = new System.Drawing.Size(182, 39);
            this.CreateMemberbutton.TabIndex = 21;
            this.CreateMemberbutton.Text = "CreateMember";
            this.CreateMemberbutton.UseVisualStyleBackColor = true;
            this.CreateMemberbutton.Click += new System.EventHandler(this.CreateMemberbutton_Click);
            // 
            // CellPhoneValue
            // 
            this.CellPhoneValue.Location = new System.Drawing.Point(157, 159);
            this.CellPhoneValue.Name = "CellPhoneValue";
            this.CellPhoneValue.Size = new System.Drawing.Size(100, 31);
            this.CellPhoneValue.TabIndex = 16;
            // 
            // CellPhonelabel
            // 
            this.CellPhonelabel.AutoSize = true;
            this.CellPhonelabel.Location = new System.Drawing.Point(14, 159);
            this.CellPhonelabel.Name = "CellPhonelabel";
            this.CellPhonelabel.Size = new System.Drawing.Size(111, 25);
            this.CellPhonelabel.TabIndex = 15;
            this.CellPhonelabel.Text = "CellPhone";
            // 
            // Emailvalue
            // 
            this.Emailvalue.Location = new System.Drawing.Point(157, 122);
            this.Emailvalue.Name = "Emailvalue";
            this.Emailvalue.Size = new System.Drawing.Size(100, 31);
            this.Emailvalue.TabIndex = 14;
            // 
            // Emaillabel
            // 
            this.Emaillabel.AutoSize = true;
            this.Emaillabel.Location = new System.Drawing.Point(14, 122);
            this.Emaillabel.Name = "Emaillabel";
            this.Emaillabel.Size = new System.Drawing.Size(65, 25);
            this.Emaillabel.TabIndex = 13;
            this.Emaillabel.Text = "Email";
            // 
            // LastNameValue
            // 
            this.LastNameValue.Location = new System.Drawing.Point(158, 80);
            this.LastNameValue.Name = "LastNameValue";
            this.LastNameValue.Size = new System.Drawing.Size(100, 31);
            this.LastNameValue.TabIndex = 12;
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Location = new System.Drawing.Point(15, 80);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(109, 25);
            this.LastNameLabel.TabIndex = 11;
            this.LastNameLabel.Text = "LastName";
            this.LastNameLabel.Click += new System.EventHandler(this.TeamOneScoreLabel_Click);
            // 
            // FirstNameValue
            // 
            this.FirstNameValue.Location = new System.Drawing.Point(158, 30);
            this.FirstNameValue.Name = "FirstNameValue";
            this.FirstNameValue.Size = new System.Drawing.Size(100, 31);
            this.FirstNameValue.TabIndex = 10;
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Location = new System.Drawing.Point(15, 33);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(110, 25);
            this.FirstNameLabel.TabIndex = 9;
            this.FirstNameLabel.Text = "FirstName";
            // 
            // TeamMemberslistBox
            // 
            this.TeamMemberslistBox.FormattingEnabled = true;
            this.TeamMemberslistBox.ItemHeight = 25;
            this.TeamMemberslistBox.Location = new System.Drawing.Point(393, 92);
            this.TeamMemberslistBox.Name = "TeamMemberslistBox";
            this.TeamMemberslistBox.Size = new System.Drawing.Size(298, 454);
            this.TeamMemberslistBox.TabIndex = 21;
            // 
            // DeleteSelectedMemberbutton
            // 
            this.DeleteSelectedMemberbutton.Location = new System.Drawing.Point(509, 552);
            this.DeleteSelectedMemberbutton.Name = "DeleteSelectedMemberbutton";
            this.DeleteSelectedMemberbutton.Size = new System.Drawing.Size(182, 39);
            this.DeleteSelectedMemberbutton.TabIndex = 22;
            this.DeleteSelectedMemberbutton.Text = "DeleteSelected";
            this.DeleteSelectedMemberbutton.UseVisualStyleBackColor = true;
            // 
            // CreateTeambutton
            // 
            this.CreateTeambutton.Location = new System.Drawing.Point(280, 552);
            this.CreateTeambutton.Name = "CreateTeambutton";
            this.CreateTeambutton.Size = new System.Drawing.Size(182, 39);
            this.CreateTeambutton.TabIndex = 23;
            this.CreateTeambutton.Text = "CreateTeam";
            this.CreateTeambutton.UseVisualStyleBackColor = true;
            // 
            // Create_Team
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(697, 749);
            this.Controls.Add(this.CreateTeambutton);
            this.Controls.Add(this.DeleteSelectedMemberbutton);
            this.Controls.Add(this.TeamMemberslistBox);
            this.Controls.Add(this.AddNewMembergroupBox);
            this.Controls.Add(this.AddMember);
            this.Controls.Add(this.SelectteammenberDropdown);
            this.Controls.Add(this.SelectteamMemberlabel);
            this.Controls.Add(this.TeamNameValue);
            this.Controls.Add(this.TeamnameLabel);
            this.Controls.Add(this.Createteamlabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Create_Team";
            this.Text = "Create_Team";
            this.Load += new System.EventHandler(this.Create_Team_Load);
            this.AddNewMembergroupBox.ResumeLayout(false);
            this.AddNewMembergroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TeamNameValue;
        private System.Windows.Forms.Label TeamnameLabel;
        private System.Windows.Forms.Label Createteamlabel;
        private System.Windows.Forms.Button AddMember;
        private System.Windows.Forms.ComboBox SelectteammenberDropdown;
        private System.Windows.Forms.Label SelectteamMemberlabel;
        private System.Windows.Forms.GroupBox AddNewMembergroupBox;
        private System.Windows.Forms.TextBox LastNameValue;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.TextBox FirstNameValue;
        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.Button CreateMemberbutton;
        private System.Windows.Forms.TextBox CellPhoneValue;
        private System.Windows.Forms.Label CellPhonelabel;
        private System.Windows.Forms.TextBox Emailvalue;
        private System.Windows.Forms.Label Emaillabel;
        private System.Windows.Forms.ListBox TeamMemberslistBox;
        private System.Windows.Forms.Button DeleteSelectedMemberbutton;
        private System.Windows.Forms.Button CreateTeambutton;
    }
}