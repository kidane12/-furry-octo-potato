﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Trackerliab;

namespace TrackerUI
{
    public partial class CreatePrize : Form
    {
        public CreatePrize()
        {
            InitializeComponent();
        }

        private void CreatePrizebutton_Click(object sender, EventArgs e)
        {
            int prizenumber=0;
            decimal prizeamount = 0;
            double prizepersentage=0;
            if (validateform())
            {
                PrizeModel model = new PrizeModel();
                model.PlaceName = PrizeNameValue.Text;
                int.TryParse(PrizeNumberValue.Text,out prizenumber);
                model.Placenumber = prizenumber;
                decimal.TryParse(PrizeAmountValue.Text, out prizeamount);
                model.Prizeamount = prizeamount;
                double.TryParse(PrizePercentagevalue.Text, out prizepersentage);
                model.Prizepercentage = prizepersentage;


                //Remove foreach
                /* foreach  (IDataConnection db in GlobalConfig.Connections)
                 {
                     db.createPrize(model);

                 }*/
                GlobalConfig.Connections.createPrize(model);


                PrizeNameValue.Text = "";
                PrizeAmountValue.Text = "";
                PrizePercentagevalue.Text = "0";


            }
            else
            {
                MessageBox.Show("Invalid");
            }

        }
        private bool validateform()
        {
            /*bool output = true;
            int placenumber = 0;

            decimal prizeAmount=0;
            int PrizePrecentage = 0;
            if(!int.TryParse(PrizeNameValue.Text,out placenumber))
            {
                output = false;
            }
            if(placenumber <1)
            {
                output = false;
            }

            if(PrizeNameValue.Text.Length == 0)
            {
                output =false;
            }

            if (!decimal.TryParse(PrizeAmountValue.Text, out prizeAmount))
            {
                output = false;
            }
            if (placenumber < 1)
            {
                output = false;
            }
            if (!int.TryParse(PrizePercentagevalue.Text, out PrizePrecentage))
            {
                output = false;
            }
            if (placenumber < 1)
            {
                output = false;
            }*/
            return true;
        }

        private void CreatePrize_Load(object sender, EventArgs e)
        {

        }
    }
}
