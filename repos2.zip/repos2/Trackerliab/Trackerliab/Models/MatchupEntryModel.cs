﻿namespace Trackerliab
{
    public class MatchupEntryModel
    {
        public Teammodel TeamCompeting { get; set; }
        public double Score { get; set; }
        public MatchupModel ParentMatchup { get; set; }

        public MatchupEntryModel(double initialscore) {
            System.Console.WriteLine();
        }
    }
}