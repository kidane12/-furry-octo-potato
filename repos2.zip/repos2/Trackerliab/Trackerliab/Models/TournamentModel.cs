﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trackerliab
{
   public class TournamentModel
    {
        public string TournamentName { get; set; }
        public decimal Entryfee { get; set; }
        public List<Teammodel> Enteredteams { get; set; } = new List<Teammodel>();
        public List<PrizeModel> Prizes { get; set; } = new List<PrizeModel>();
        public List<List<MatchupModel>> Rounds { get; set; } = new List<List<MatchupModel>>();
    }
}
