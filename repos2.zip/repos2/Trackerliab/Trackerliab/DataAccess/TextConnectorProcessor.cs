﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trackerliab.DataAccess.TextConnector
{
    public static class TextConnectorProcessor
    {
        public static string FullfilePath(this string filename)
        {
            return null;//$"{ConfigrationManager.AppSettings["filePath"]}";
        }
    }
}
