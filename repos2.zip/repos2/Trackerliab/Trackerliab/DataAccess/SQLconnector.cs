﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trackerliab
{
    public class SQLconnector : IDataConnection
    {
        public PersonModel CreatePerson(PersonModel p)
        {
            p.id=1;
            return p;
        }
        public PrizeModel createPrize(PrizeModel model)
        {
            model.Id=1;
            return model;
        }
    }
}
