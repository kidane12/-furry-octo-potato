﻿using System;
using System.Linq;
using Anon.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProjectPCM
{
    [TestClass]
    public class UnitTest1
    {

        Declass d = new Declass();
        [TestMethod]
        public void Attributes_Properly_Parsed()
        {
            foreach (var e in d.speakerModel.AttributeTypes.ToList())
            {
                if (e.HasBounds == "0")
                {
                    /*foreach (var x in e.EcResBoundedAttributeTypeValue.ToList())
                    {
                        Console.WriteLine(x.Lower);
                        Console.WriteLine(x.Upper);
                    }*/
                    Assert.AreNotEqual(e.EcoResBoundedAttributeTypeValue, null);
                }
            }
        }
        [TestMethod]
        public void Components_Properly_Parsed()
        {
        }

        [TestMethod]
        public void ExportPCProductConfigurationModel_Properly_Parsed()
        {
        }

        [TestMethod]
        public void TableConstraintDefintions_Properly_Parsed()
        {
        }


    }
}
