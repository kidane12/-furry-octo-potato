﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleAppSer
{
    class Program
    {
        static void Main(string[] args)
        {
            Person pp = new Person("a", "b", 12);
            Serialize(pp);
        }
        public static void Serialize(Person p)
        {
            XmlSerializer s = new XmlSerializer(typeof(Person));
            TextWriter writer = new StreamWriter("personss.xml");
            s.Serialize(writer, p);
            writer.Close();


        }
        
    }
    public class Person
    {

        public Person()
        {

        }
        public Person(string n, string loc, int a)
        {
            name = n;
            this.loc = loc;
            age = a;
        }
        private string name, loc;
        private int age;

    }
}
