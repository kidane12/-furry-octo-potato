﻿namespace TrackerUI
{
    partial class Create_team
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateTeamlabel = new System.Windows.Forms.Label();
            this.TNamelabel = new System.Windows.Forms.Label();
            this.TMemberlabel = new System.Windows.Forms.Label();
            this.AddMemberbutton = new System.Windows.Forms.Button();
            this.TNameValue = new System.Windows.Forms.TextBox();
            this.TMemberValue = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.FNamelabel = new System.Windows.Forms.Label();
            this.LName = new System.Windows.Forms.Label();
            this.Emaillabel = new System.Windows.Forms.Label();
            this.FNameValue = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.EmailValue = new System.Windows.Forms.TextBox();
            this.CreateMember = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CreateTeamlabel
            // 
            this.CreateTeamlabel.AutoSize = true;
            this.CreateTeamlabel.Location = new System.Drawing.Point(15, 9);
            this.CreateTeamlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.CreateTeamlabel.Name = "CreateTeamlabel";
            this.CreateTeamlabel.Size = new System.Drawing.Size(130, 25);
            this.CreateTeamlabel.TabIndex = 0;
            this.CreateTeamlabel.Text = "CreateTeam";
            this.CreateTeamlabel.Click += new System.EventHandler(this.Label1_Click);
            // 
            // TNamelabel
            // 
            this.TNamelabel.AutoSize = true;
            this.TNamelabel.Location = new System.Drawing.Point(15, 56);
            this.TNamelabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TNamelabel.Name = "TNamelabel";
            this.TNamelabel.Size = new System.Drawing.Size(81, 25);
            this.TNamelabel.TabIndex = 1;
            this.TNamelabel.Text = "TName";
            // 
            // TMemberlabel
            // 
            this.TMemberlabel.AutoSize = true;
            this.TMemberlabel.Location = new System.Drawing.Point(15, 138);
            this.TMemberlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TMemberlabel.Name = "TMemberlabel";
            this.TMemberlabel.Size = new System.Drawing.Size(103, 25);
            this.TMemberlabel.TabIndex = 2;
            this.TMemberlabel.Text = "TMember";
            // 
            // AddMemberbutton
            // 
            this.AddMemberbutton.Location = new System.Drawing.Point(43, 212);
            this.AddMemberbutton.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.AddMemberbutton.Name = "AddMemberbutton";
            this.AddMemberbutton.Size = new System.Drawing.Size(150, 44);
            this.AddMemberbutton.TabIndex = 3;
            this.AddMemberbutton.Text = "AddMember";
            this.AddMemberbutton.UseVisualStyleBackColor = true;
            // 
            // TNameValue
            // 
            this.TNameValue.Location = new System.Drawing.Point(20, 87);
            this.TNameValue.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TNameValue.Name = "TNameValue";
            this.TNameValue.Size = new System.Drawing.Size(196, 31);
            this.TNameValue.TabIndex = 4;
            // 
            // TMemberValue
            // 
            this.TMemberValue.FormattingEnabled = true;
            this.TMemberValue.Location = new System.Drawing.Point(20, 170);
            this.TMemberValue.Name = "TMemberValue";
            this.TMemberValue.Size = new System.Drawing.Size(196, 33);
            this.TMemberValue.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CreateMember);
            this.groupBox1.Controls.Add(this.EmailValue);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.FNameValue);
            this.groupBox1.Controls.Add(this.Emaillabel);
            this.groupBox1.Controls.Add(this.LName);
            this.groupBox1.Controls.Add(this.FNamelabel);
            this.groupBox1.Location = new System.Drawing.Point(20, 265);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(289, 218);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(650, 362);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "label4";
            // 
            // FNamelabel
            // 
            this.FNamelabel.AutoSize = true;
            this.FNamelabel.Location = new System.Drawing.Point(9, 39);
            this.FNamelabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.FNamelabel.Name = "FNamelabel";
            this.FNamelabel.Size = new System.Drawing.Size(81, 25);
            this.FNamelabel.TabIndex = 9;
            this.FNamelabel.Text = "FName";
            // 
            // LName
            // 
            this.LName.AutoSize = true;
            this.LName.Location = new System.Drawing.Point(9, 78);
            this.LName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(80, 25);
            this.LName.TabIndex = 10;
            this.LName.Text = "LName";
            // 
            // Emaillabel
            // 
            this.Emaillabel.AutoSize = true;
            this.Emaillabel.Location = new System.Drawing.Point(9, 119);
            this.Emaillabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Emaillabel.Name = "Emaillabel";
            this.Emaillabel.Size = new System.Drawing.Size(65, 25);
            this.Emaillabel.TabIndex = 11;
            this.Emaillabel.Text = "Email";
            // 
            // FNameValue
            // 
            this.FNameValue.Location = new System.Drawing.Point(84, 39);
            this.FNameValue.Margin = new System.Windows.Forms.Padding(6);
            this.FNameValue.Name = "FNameValue";
            this.FNameValue.Size = new System.Drawing.Size(196, 31);
            this.FNameValue.TabIndex = 9;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(84, 78);
            this.textBox3.Margin = new System.Windows.Forms.Padding(6);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(196, 31);
            this.textBox3.TabIndex = 12;
            // 
            // EmailValue
            // 
            this.EmailValue.Location = new System.Drawing.Point(84, 121);
            this.EmailValue.Margin = new System.Windows.Forms.Padding(6);
            this.EmailValue.Name = "EmailValue";
            this.EmailValue.Size = new System.Drawing.Size(196, 31);
            this.EmailValue.TabIndex = 13;
            // 
            // CreateMember
            // 
            this.CreateMember.Location = new System.Drawing.Point(84, 164);
            this.CreateMember.Margin = new System.Windows.Forms.Padding(6);
            this.CreateMember.Name = "CreateMember";
            this.CreateMember.Size = new System.Drawing.Size(150, 44);
            this.CreateMember.TabIndex = 9;
            this.CreateMember.Text = "button2";
            this.CreateMember.UseVisualStyleBackColor = true;
            // 
            // Create_team
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 749);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TMemberValue);
            this.Controls.Add(this.TNameValue);
            this.Controls.Add(this.AddMemberbutton);
            this.Controls.Add(this.TMemberlabel);
            this.Controls.Add(this.TNamelabel);
            this.Controls.Add(this.CreateTeamlabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Create_team";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CreateTeamlabel;
        private System.Windows.Forms.Label TNamelabel;
        private System.Windows.Forms.Label TMemberlabel;
        private System.Windows.Forms.Button AddMemberbutton;
        private System.Windows.Forms.TextBox TNameValue;
        private System.Windows.Forms.ComboBox TMemberValue;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button CreateMember;
        private System.Windows.Forms.TextBox EmailValue;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox FNameValue;
        private System.Windows.Forms.Label Emaillabel;
        private System.Windows.Forms.Label LName;
        private System.Windows.Forms.Label FNamelabel;
        private System.Windows.Forms.Label label4;
    }
}

