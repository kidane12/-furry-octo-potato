﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrackerLiabrary.Models;

namespace TrackerUI
{
    public partial class CreatePrizes : Form
    {
        public CreatePrizes()
        {
            InitializeComponent();
        }

        private void CreatePrizes_Load(object sender, EventArgs e)
        {
            


        }

        private void CreatePrize_Click(object sender, EventArgs e)
        {
            int prizenumber = 0;
            decimal prizeamount = 0;
            double prizepersentage = 0;

            PrizeModel model = new PrizeModel();
            model.PlaceName = PrizeNameValue.Text;
            int.TryParse(PrizeNumberValue.Text, out prizenumber);
            model.Placenumber = prizenumber;
            decimal.TryParse(PrizeAmountValue.Text, out prizeamount);
            model.Prizeamount = prizeamount;
            double.TryParse(PrizePercentageValue.Text, out prizepersentage);
            model.Prizepercentage = prizepersentage;

            PrizeNameValue.Text = "";
            PrizeAmountValue.Text = "";
            PrizePercentageValue.Text = "0";
        }
    }
}
