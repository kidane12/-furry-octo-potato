﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackerLiabrary.Models;

namespace TrackerLiabrary.DataAccess
{
    public interface IDataConnection
    {
        PrizeModel createPrize(PrizeModel model);
        PersonModel CreatePerson(PersonModel p);
    }
}
