﻿namespace TrackerUI
{
    partial class CreatePrizes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreatePrize = new System.Windows.Forms.Button();
            this.PrizeNummberlabel = new System.Windows.Forms.Label();
            this.PrizePercentagelabel = new System.Windows.Forms.Label();
            this.PrizeAmountlabel = new System.Windows.Forms.Label();
            this.PrizeNamelabel = new System.Windows.Forms.Label();
            this.PrizeNumberValue = new System.Windows.Forms.TextBox();
            this.PrizePercentageValue = new System.Windows.Forms.TextBox();
            this.PrizeAmountValue = new System.Windows.Forms.TextBox();
            this.PrizeNameValue = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // CreatePrize
            // 
            this.CreatePrize.Location = new System.Drawing.Point(60, 232);
            this.CreatePrize.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.CreatePrize.Name = "CreatePrize";
            this.CreatePrize.Size = new System.Drawing.Size(150, 44);
            this.CreatePrize.TabIndex = 0;
            this.CreatePrize.Text = "CreatePrize";
            this.CreatePrize.UseVisualStyleBackColor = true;
            this.CreatePrize.Click += new System.EventHandler(this.CreatePrize_Click);
            // 
            // PrizeNummberlabel
            // 
            this.PrizeNummberlabel.AutoSize = true;
            this.PrizeNummberlabel.Location = new System.Drawing.Point(25, 21);
            this.PrizeNummberlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizeNummberlabel.Name = "PrizeNummberlabel";
            this.PrizeNummberlabel.Size = new System.Drawing.Size(153, 25);
            this.PrizeNummberlabel.TabIndex = 1;
            this.PrizeNummberlabel.Text = "PrizeNummber";
            // 
            // PrizePercentagelabel
            // 
            this.PrizePercentagelabel.AutoSize = true;
            this.PrizePercentagelabel.Location = new System.Drawing.Point(25, 169);
            this.PrizePercentagelabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizePercentagelabel.Name = "PrizePercentagelabel";
            this.PrizePercentagelabel.Size = new System.Drawing.Size(171, 25);
            this.PrizePercentagelabel.TabIndex = 3;
            this.PrizePercentagelabel.Text = "PrizePercentage";
            // 
            // PrizeAmountlabel
            // 
            this.PrizeAmountlabel.AutoSize = true;
            this.PrizeAmountlabel.Location = new System.Drawing.Point(25, 122);
            this.PrizeAmountlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizeAmountlabel.Name = "PrizeAmountlabel";
            this.PrizeAmountlabel.Size = new System.Drawing.Size(134, 25);
            this.PrizeAmountlabel.TabIndex = 4;
            this.PrizeAmountlabel.Text = "PrizeAmount";
            // 
            // PrizeNamelabel
            // 
            this.PrizeNamelabel.AutoSize = true;
            this.PrizeNamelabel.Location = new System.Drawing.Point(25, 67);
            this.PrizeNamelabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PrizeNamelabel.Name = "PrizeNamelabel";
            this.PrizeNamelabel.Size = new System.Drawing.Size(117, 25);
            this.PrizeNamelabel.TabIndex = 5;
            this.PrizeNamelabel.Text = "PrizeName";
            // 
            // PrizeNumberValue
            // 
            this.PrizeNumberValue.Location = new System.Drawing.Point(198, 15);
            this.PrizeNumberValue.Name = "PrizeNumberValue";
            this.PrizeNumberValue.Size = new System.Drawing.Size(100, 31);
            this.PrizeNumberValue.TabIndex = 6;
            // 
            // PrizePercentageValue
            // 
            this.PrizePercentageValue.Location = new System.Drawing.Point(198, 169);
            this.PrizePercentageValue.Name = "PrizePercentageValue";
            this.PrizePercentageValue.Size = new System.Drawing.Size(100, 31);
            this.PrizePercentageValue.TabIndex = 7;
            // 
            // PrizeAmountValue
            // 
            this.PrizeAmountValue.Location = new System.Drawing.Point(198, 122);
            this.PrizeAmountValue.Name = "PrizeAmountValue";
            this.PrizeAmountValue.Size = new System.Drawing.Size(100, 31);
            this.PrizeAmountValue.TabIndex = 8;
            // 
            // PrizeNameValue
            // 
            this.PrizeNameValue.Location = new System.Drawing.Point(198, 61);
            this.PrizeNameValue.Name = "PrizeNameValue";
            this.PrizeNameValue.Size = new System.Drawing.Size(100, 31);
            this.PrizeNameValue.TabIndex = 9;
            // 
            // CreatePrizes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 749);
            this.Controls.Add(this.PrizeNameValue);
            this.Controls.Add(this.PrizeAmountValue);
            this.Controls.Add(this.PrizePercentageValue);
            this.Controls.Add(this.PrizeNumberValue);
            this.Controls.Add(this.PrizeNamelabel);
            this.Controls.Add(this.PrizeAmountlabel);
            this.Controls.Add(this.PrizePercentagelabel);
            this.Controls.Add(this.PrizeNummberlabel);
            this.Controls.Add(this.CreatePrize);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "CreatePrizes";
            this.Text = "CreatePrizes";
            this.Load += new System.EventHandler(this.CreatePrizes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CreatePrize;
        private System.Windows.Forms.Label PrizeNummberlabel;
        private System.Windows.Forms.Label PrizePercentagelabel;
        private System.Windows.Forms.Label PrizeAmountlabel;
        private System.Windows.Forms.Label PrizeNamelabel;
        private System.Windows.Forms.TextBox PrizeNumberValue;
        private System.Windows.Forms.TextBox PrizePercentageValue;
        private System.Windows.Forms.TextBox PrizeAmountValue;
        private System.Windows.Forms.TextBox PrizeNameValue;
    }
}