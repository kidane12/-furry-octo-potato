﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackerLiabrary.DataAccess;

namespace TrackerLiabrary
{
    public static class GlobalConfig
    {
        public static IDataConnection Connections { get; private set; }
        public static void InitializeConnections(Databasetype db)
        {
            /*if (db == Databasetype.sql)
            {
                //SQL
                SQLconnector sql = new SQLconnector();
                Connections = sql;

            }*/
            if (db == Databasetype.textfile)
            {
                //Text
                TextConnector text = new TextConnector();
                Connections = text;
            }
        }
    }
}
