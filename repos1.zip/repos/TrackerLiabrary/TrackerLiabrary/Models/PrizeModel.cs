﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackerLiabrary.Models
{
   public class PrizeModel
    {
        public int Id { get; set; }
        public int Placenumber { get; set; }
        public string PlaceName { get; set; }
        public decimal Prizeamount { get; set; }
        public double Prizepercentage { get; set; }
    }
}
