﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackerLiabrary.Models
{
    class TournamentModel
    {
        public string TournamentName { get; set; }
        public decimal Entryfee { get; set; }
        public List<TeamModel> Enteredteams { get; set; } = new List<TeamModel>();
        public List<PrizeModel> Prizes { get; set; } = new List<PrizeModel>();
        public List<List<MatchupModel>> Rounds { get; set; } = new List<List<MatchupModel>>();
    }
}
