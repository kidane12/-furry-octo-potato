﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackerLiabrary.Models;
using TrackerLiabrary.DataAccess.TextHelpers;
namespace TrackerLiabrary.DataAccess
{
    public class TextConnector: IDataConnection
    {
        private const string PrizeFile = "PrizeModels.csv";
        public PersonModel CreatePerson(PersonModel p)
        {
            throw new NotImplementedException();
        }

        public PrizeModel createPrize(PrizeModel model)
        {
            List<PrizeModel> prizes = PrizeFile.FullfilePath().LoadFile().ConvertToPrizeModels();

            int currentId = 1;

            if(prizes.Count > 0)
            {
                currentId = prizes.OrderByDescending(x => x.Id).First().Id + 1;
            }
            model.Id = currentId;
            prizes.Add(model);
            prizes.saveToPrizeFile(PrizeFile);
            return model;

        }
    }
}
