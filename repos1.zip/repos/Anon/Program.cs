﻿using Anon.Dataxml;
using Anon.Helpers;
using Anon.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Anon
{
    public class Program
    {
        //Declass p = new Declass();
        //Export export = new Export();
        


        public static void Main(string[] args)
        {
            //Declass p = new Declass();
            //Export export = new Export();
            Searchers s = new Searchers();
            s.AttributeSearcher("name");
            s.TableConstraintDefintions("name");
            s.Components("Name");
            s.PCConfugrationmodel("Name");













        }
    }
}
