﻿using Anon.Dataxml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Anon.Model
{
    /*public class Declass
    {

        public List<ExportAttributeTypesEcoResAttributeType> LAttributes;
        public List<ExportTableConstraintDefintionsPCGlobalTableConstraintDefinition> TTableConstraintDefintions;
        public List<ExportComponentsPCClass> CComponents;
        public List<ExportPCProductConfigurationModel> EExportPCProductConfigurationModel;
        public Export speakerModel;
        public Declass()
        {
            XmlSerializer s = new XmlSerializer(typeof(Export));
            
            using (var sr = new StringReader(XmlModels.SpeakerSolution))
            {
                try
                {
                    speakerModel = (Export)s.Deserialize(sr);
                }
                catch(Exception e)
                {
                    Console.WriteLine("Can't be Serialized", e);
                }
            }
            this.LAttributes = speakerModel.AttributeTypes.ToList();
            this.TTableConstraintDefintions = speakerModel.TableConstraintDefintions.ToList();
            this.CComponents = speakerModel.Components.ToList();
            this.EExportPCProductConfigurationModel = speakerModel.PCProductConfigurationModel.ToList();
        }

      
    }*/
}
