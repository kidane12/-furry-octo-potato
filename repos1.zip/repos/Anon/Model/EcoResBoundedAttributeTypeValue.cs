﻿namespace Anon.Model
{
    public class EcoResBoundedAttributeTypeValue
    {
        public int lower { get; set; }
        public int upper { get; set; }

    }
}