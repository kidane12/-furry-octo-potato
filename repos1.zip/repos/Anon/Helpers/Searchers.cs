﻿using Anon.Dataxml;
using Anon.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Anon.Helpers
{
    class Searchers
    {
        public Declass p = new Declass();
        public void AttributeSearcher(string name)
        {

            foreach (var atr in p.LAttributes)
            {
                if (atr.HasBounds == "1")
                {
                    foreach (var atrr in atr.EcoResBoundedAttributeTypeValue.ToList())
                    {
                        Console.WriteLine("Upper Bound is {0}, Lower Bound is {1}", atrr.Upper, atrr.Lower);
                        //Console.WriteLine(atrr.Upper);

                    }
                }
                if (atr.IsEnumeration == "1")
                {
                    foreach (var EnumAttributeType in atr.EcoResEnumerationAttributeTypeValue.ToList())
                    {
                        Console.WriteLine("OrdinalNumber is {0}, EnumerationValue is {1}, SolverValue is {2}",
                            EnumAttributeType.OrdinalNumber, EnumAttributeType.EnumerationValue, EnumAttributeType.SolverValue);

                        foreach (var x in EnumAttributeType.EcoResTextValueTranslation.ToList())
                        {
                            Console.WriteLine(x.TextValue, x.Language);
                        }
                        //Console.WriteLine(atrr.Upper);

                    }
                }

            }

        }
        public void TableConstraintDefintions(string value)
        {
            foreach (var cons in p.TTableConstraintDefintions)
            {
                foreach (var GlobalColmn in cons.PCTableConstraintGlobalColumnDef.ToList())
                {
                    Console.WriteLine("===========================================================================================");
                    Console.WriteLine("Name {0},Description {1}", GlobalColmn.Name, GlobalColmn.AttributeType);

                }
                foreach (var GlobalColmn in cons.PCTableConstraintRow.ToList())
                {

                    Console.WriteLine("===========================================================================================");
                    Console.WriteLine("ConstraintCell {0}", GlobalColmn.Value);
                }


            }


        }

        public void Components(string value)
        {
            foreach (var component in p.CComponents)
            {
                Console.WriteLine("==========================Components=============================");
                Console.WriteLine("Component name {0}, ReUseEnabled {1}", component.Name, component.ReuseEnabled);

                foreach (var CatTranslation in component.EcoResCategoryTranslation.ToList())
                {
                    Console.WriteLine("=================================EcoResCategoryTranslation====================================================");
                    Console.WriteLine("Name {0},Description {1}, LanguageId {2}", CatTranslation.FriendlyName, CatTranslation.Description, CatTranslation.LanguageId);

                }
                foreach (var RAttribute in component.EcoResAttribute.ToList())
                {

                    Console.WriteLine("==============================EcoResAttribute=============================================================");
                    Console.WriteLine("Name {0}, Solver Name {1}, Attribute Type {2}, InCludeInReuse {3}", RAttribute.Name, RAttribute.SolverName, RAttribute.AttributeType, RAttribute.IncludeInReuse);

                    foreach (var AttrTranslation in RAttribute.EcoResAttributeTranslation.ToList())
                    {
                        Console.WriteLine("=======================================EcoreaAttributeTranslation==============================================");
                        Console.WriteLine("Friendly Name {0},Description {1}, Language {2}", AttrTranslation.FriendlyName, AttrTranslation.Description, AttrTranslation.Language);
                    }

                    if(RAttribute.EcoResComponentControl!= null)
                    {
                        foreach (var compControl in RAttribute.EcoResComponentControl.ToList())
                        {
                            Console.WriteLine("=======================================EcoResComponentControl==============================================");
                            Console.WriteLine("Modifier {0}", compControl.Modifier);


                            foreach (var Express in compControl.PCExpressionConstraint.ToList())
                            {
                                if (Express.Expression != null)
                                {
                                    Console.WriteLine("Expression {0}", Express.Expression);
                                }

                            }



                        }

                    }


                    
                }


                if (component.PCComponentConstraint != null)
                {
                    foreach (var CompConstraint in component.PCComponentConstraint.ToList())
                    {
                        Console.WriteLine("=============================PCComponentConstraint==============================================");
                        Console.WriteLine("Name {0}, Description {1}", CompConstraint.Name, CompConstraint.Description);

                        if (CompConstraint.PCExpressionConstraint != null)
                        {
                            foreach (var expConstraint in CompConstraint.PCExpressionConstraint.ToList())
                            {
                                Console.WriteLine("================================PCExpressionConstraint=======================================");
                                Console.WriteLine(expConstraint.Expression);
                            }
                        }
                        //This is always returning null for some reason
                        if (CompConstraint.PCTableConstraint != null)
                        {
                            foreach (var ColmnCategoryAttribute in CompConstraint.PCTableConstraint.ToList())
                            {
                                Console.WriteLine("================================PCTableConstraint=======================================");
                                Console.WriteLine("PCTableConstraintDefinition {0}" , ColmnCategoryAttribute.PCTableConstraintDefinition);

                                foreach (var ConsColmnCatAttribute in ColmnCategoryAttribute.PCTableConstraintColumnCategoryAttribute.ToList())
                                {
                                    Console.WriteLine("================================PCTableConstraintColumnCategoryAttribute=======================================");
                                    Console.WriteLine("TableConstraintColumn {0}, Attribute {1}", ConsColmnCatAttribute.TableConstraintColumn, ConsColmnCatAttribute.Attribute);

                                }
                            }
                        }

                    }

                }

                if (component.PCCalculation != null)
                {
                    foreach (var Calculation in component.PCCalculation.ToList())
                    {
                        Console.WriteLine("====================================================PcCalculation============================================================================");
                        Console.WriteLine("Name {0}, Description {1}, TargetAttribute {2}, Expression {3}", Calculation.Name, Calculation.Description, Calculation.TargetAttribute, Calculation.Expression);
                    }
                }



                foreach (var Template in component.PCTemplateComponent.ToList())
                {
                    Console.WriteLine("====================================================PCTemplateComponent============================================================================");
                    Console.WriteLine("Name {0}, Requarement {1}, Description {2}", Template.Name, Template.Requirement, Template.Description);

                    foreach (var ExpConstraint in Template.PCExpressionConstraint.ToList())
                    {
                        Console.WriteLine("===============================PCExpressionConstraint===========================================================================================");
                        Console.WriteLine("Expression {0}", ExpConstraint.Expression);

                    }

                    foreach (var TemplateConstraint in Template.PCTemplateConstant.ToList())
                    {
                        Console.WriteLine("===============================PCTemplateConstant===========================================================================================");
                        Console.WriteLine("TableName {0}, FieldName {1}, Value {2}", TemplateConstraint.TableName, TemplateConstraint.FieldName, TemplateConstraint.Value);

                    }

                    if(Template.PCTemplateCategoryAttribute != null)
                    {
                        foreach (var TemplateCategoryAttrib in Template.PCTemplateCategoryAttribute.ToList())
                        {
                            Console.WriteLine("===============================PCTemplateCategoryAttribute===========================================================================================");
                            Console.WriteLine("TableName {0}, FieldName {1}, Attribute {2}", TemplateCategoryAttrib.TableName, TemplateCategoryAttrib.FieldName, TemplateCategoryAttrib.Attribute);

                        }

                    }

                    if (Template.WrkCtrPCRouteOperationActivity != null)
                    {


                        foreach (var WrkCtrRoutOprActivity in Template.WrkCtrPCRouteOperationActivity.ToList())
                        {
                            Console.WriteLine("===============================WrkCtrPCRouteOperationActivity===========================================================================================");
                            Console.WriteLine("Description {0}, Quantity {1}, LoadPercent {2}", WrkCtrRoutOprActivity.Description, WrkCtrRoutOprActivity.Quantity, WrkCtrRoutOprActivity.LoadPercent);

                            foreach (var WrkCtrActivityCapRequarement in WrkCtrRoutOprActivity.WrkCtrActivityCapabilityRequirement.ToList())
                            {
                                Console.WriteLine("===============================WrkCtrActivityCapabilityRequirement============================================================================");
                                Console.WriteLine("UsedForJobScheduling {0}, UsedForOperationScheduling {1}, Capability {2}", WrkCtrActivityCapRequarement.UsedForJobScheduling, WrkCtrActivityCapRequarement.UsedForOperationScheduling, WrkCtrActivityCapRequarement.Capability);

                            }

                        }
                    }

                }

                if (component.PCComponentConfigurationNomenclature != null)
                {
                    foreach (var CompConfNomenclature in component.PCComponentConfigurationNomenclature.ToList())
                    {
                        Console.WriteLine("===============================PCComponentConfigurationNomenclature========================================================================");
                        Console.WriteLine("NomenclatureRole {0}, IsActive {1}", CompConfNomenclature.NomenclatureRole, CompConfNomenclature.IsActive);

                        foreach(var ConfNomenclature in CompConfNomenclature.PCConfigurationNomenclature)
                        {
                            Console.WriteLine("===============================PCConfigurationNomenclature========================================================================");
                            Console.WriteLine("Name {0}, Description {1}", ConfNomenclature.Name, ConfNomenclature.Description);

                            foreach (var ResNomenclatureSegAttrval in ConfNomenclature.EcoResNomenclatureSegmentAttributeValue.ToList())
                            {
                                Console.WriteLine("===============================EcoResNomenclatureSegmentAttributeValue================================================================");
                                Console.WriteLine("SegmentNumber {0}, Attribute {1}", ResNomenclatureSegAttrval.SegmentNumber, ResNomenclatureSegAttrval.Attribute);
                            }
                            foreach (var ResNomenclatureSegTxtConstant in ConfNomenclature.EcoResNomenclatureSegmentTextConstant.ToList())
                            {
                                Console.WriteLine("===============================EcoResNomenclatureSegmentTextConstant================================================================");
                                Console.WriteLine("SegmentNumber {0}, Text {1}", ResNomenclatureSegTxtConstant.SegmentNumber, ResNomenclatureSegTxtConstant.Text);
                            }

                            foreach (var ResNomenclatureSegNumSequence in ConfNomenclature.EcoResNomenclatureSegmentNumberSequence.ToList())
                            {
                                Console.WriteLine("===============================EcoResNomenclatureSegmentTextConstant================================================================");
                                Console.WriteLine("SegmentNumber {0}, NumberSequence {1}", ResNomenclatureSegNumSequence.SegmentNumber, ResNomenclatureSegNumSequence.NumberSequence);
                            }
                        }

                    }
                }
                
               


            }


        }

        public void PCConfugrationmodel(string name)
        {
            foreach (var prdConfModel in p.EExportPCProductConfigurationModel)
            {
                Console.WriteLine("===============================EExportPCProductConfigurationModel================================================================");
                Console.WriteLine("Name {0}, RootComponentClass {1}, SolverStrategy {2}, Columns {3}", prdConfModel.Name, prdConfModel.RootComponentClass, prdConfModel.SolverStrategy, prdConfModel.Columns);

                foreach (var prdConfModelTranslation in prdConfModel.PCProductConfigurationModelTranslation.ToList())
                {
                    Console.WriteLine("===============================PCProductConfigurationModelTranslation================================================================");
                    Console.WriteLine("Name {0}, Description {1}, Language {0}", prdConfModelTranslation.Name, prdConfModelTranslation.Description, prdConfModelTranslation.Language);
                }

                //That doesn't work because it's commented in the XML
                if (prdConfModel.PCConfigurationControl != null)
                {

                    foreach (var PcConfCntrol in prdConfModel.PCConfigurationControl)
                    {
                        Console.WriteLine("===============================PCConfigurationControl===============================================================");
                        //Console.WriteLine("Name { 0}, Description { 1}, Language { 0}", PcConfCntrol.);

                    }
                }



                foreach (var PriceModel in prdConfModel.PCPriceModel.ToList())
                {
                    Console.WriteLine("===============================PCPriceModel===============================================================");
                    Console.WriteLine("Name {0}, Description {1}", PriceModel.Name, PriceModel.Description);


                    foreach (var PriceCalc in PriceModel.PCClassPriceCalculation.ToList())
                    {
                        Console.WriteLine("===============================PCClassPriceCalculation===============================================================");
                        Console.WriteLine("Component {0}", PriceCalc.Component);

                        if (PriceCalc.PCPriceBasePrice !=null)
                        {
                            foreach (var BasePrice in PriceCalc.PCPriceBasePrice.ToList())
                            {
                                Console.WriteLine("===============================PCPriceBasePrice===============================================================");
                                Console.WriteLine("BasePrice {0}", BasePrice.Name);

                                foreach (var PriceExpVal in BasePrice.PCPriceExpressionValue.ToList())
                                {
                                    Console.WriteLine("===============================PCPriceExpressionValue===============================================================");
                                    Console.WriteLine("PriceExpression {0}, Currency {1}", PriceExpVal.PriceExpression, PriceExpVal.Currency);
                                }
                            }
                        }

                        foreach (var PriceExprRule in PriceCalc.PCPriceExpressionRule.ToList())
                        {
                            Console.WriteLine("===============================PCPriceBasePrice===============================================================");
                            Console.WriteLine("BasePrice {0}, Condition {1}", PriceExprRule.Name, PriceExprRule.Condition);

                            foreach (var PriceExpVal in PriceExprRule.PCPriceExpressionValue.ToList())
                            {
                                Console.WriteLine("===============================PCPriceExpressionValue===============================================================");
                                Console.WriteLine("PriceExpression {0}, Currency {1}", PriceExpVal.PriceExpression, PriceExpVal.Currency);
                            }
                        }


                    }



                }

            }
        }


    }

    internal class Declass
    {
        public List<ExportAttributeTypesEcoResAttributeType> LAttributes;
        public List<ExportTableConstraintDefintionsPCGlobalTableConstraintDefinition> TTableConstraintDefintions;
        public List<ExportComponentsPCClass> CComponents;
        public List<ExportPCProductConfigurationModel> EExportPCProductConfigurationModel;
        public Export speakerModel;
        public Declass()
        {
            XmlSerializer s = new XmlSerializer(typeof(Export));

            using (var sr = new StringReader(XmlModels.SpeakerSolution))
            {
                try
                {
                    speakerModel = (Export)s.Deserialize(sr);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Can't be Serialized", e);
                }
            }
            this.LAttributes = speakerModel.AttributeTypes.ToList();
            this.TTableConstraintDefintions = speakerModel.TableConstraintDefintions.ToList();
            this.CComponents = speakerModel.Components.ToList();
            this.EExportPCProductConfigurationModel = speakerModel.PCProductConfigurationModel.ToList();
        }
    }
}
