﻿namespace TrackerUI
{
    partial class TournamentDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TournamentDashboardLabel = new System.Windows.Forms.Label();
            this.LoadExistingTournamentlabel = new System.Windows.Forms.Label();
            this.LoadTournamentbutton = new System.Windows.Forms.Button();
            this.CreateTournamentbutton = new System.Windows.Forms.Button();
            this.ExistingTournamentValue = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // TournamentDashboardLabel
            // 
            this.TournamentDashboardLabel.AutoSize = true;
            this.TournamentDashboardLabel.Location = new System.Drawing.Point(109, 9);
            this.TournamentDashboardLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TournamentDashboardLabel.Name = "TournamentDashboardLabel";
            this.TournamentDashboardLabel.Size = new System.Drawing.Size(232, 25);
            this.TournamentDashboardLabel.TabIndex = 14;
            this.TournamentDashboardLabel.Text = "TournamentDashboard";
            // 
            // LoadExistingTournamentlabel
            // 
            this.LoadExistingTournamentlabel.AutoSize = true;
            this.LoadExistingTournamentlabel.Location = new System.Drawing.Point(109, 68);
            this.LoadExistingTournamentlabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LoadExistingTournamentlabel.Name = "LoadExistingTournamentlabel";
            this.LoadExistingTournamentlabel.Size = new System.Drawing.Size(251, 25);
            this.LoadExistingTournamentlabel.TabIndex = 15;
            this.LoadExistingTournamentlabel.Text = "LoadExistingTournament";
            // 
            // LoadTournamentbutton
            // 
            this.LoadTournamentbutton.Location = new System.Drawing.Point(153, 167);
            this.LoadTournamentbutton.Name = "LoadTournamentbutton";
            this.LoadTournamentbutton.Size = new System.Drawing.Size(188, 41);
            this.LoadTournamentbutton.TabIndex = 21;
            this.LoadTournamentbutton.Text = "LoadTournament";
            this.LoadTournamentbutton.UseVisualStyleBackColor = true;
            // 
            // CreateTournamentbutton
            // 
            this.CreateTournamentbutton.Location = new System.Drawing.Point(149, 224);
            this.CreateTournamentbutton.Name = "CreateTournamentbutton";
            this.CreateTournamentbutton.Size = new System.Drawing.Size(211, 41);
            this.CreateTournamentbutton.TabIndex = 22;
            this.CreateTournamentbutton.Text = "CreateTournament";
            this.CreateTournamentbutton.UseVisualStyleBackColor = true;
            // 
            // ExistingTournamentValue
            // 
            this.ExistingTournamentValue.FormattingEnabled = true;
            this.ExistingTournamentValue.Location = new System.Drawing.Point(114, 110);
            this.ExistingTournamentValue.Name = "ExistingTournamentValue";
            this.ExistingTournamentValue.Size = new System.Drawing.Size(252, 33);
            this.ExistingTournamentValue.TabIndex = 23;
            // 
            // TournamentDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 749);
            this.Controls.Add(this.ExistingTournamentValue);
            this.Controls.Add(this.CreateTournamentbutton);
            this.Controls.Add(this.LoadTournamentbutton);
            this.Controls.Add(this.LoadExistingTournamentlabel);
            this.Controls.Add(this.TournamentDashboardLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "TournamentDashboard";
            this.Text = "TournamentDashboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TournamentDashboardLabel;
        private System.Windows.Forms.Label LoadExistingTournamentlabel;
        private System.Windows.Forms.Button LoadTournamentbutton;
        private System.Windows.Forms.Button CreateTournamentbutton;
        private System.Windows.Forms.ComboBox ExistingTournamentValue;
    }
}