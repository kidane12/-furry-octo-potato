﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Trackerliab;

namespace TrackerUI
{
    public partial class Create_Team : Form
    {
        public Create_Team()
        {
            InitializeComponent();
        }

        private void TeamOneScoreLabel_Click(object sender, EventArgs e)
        {

        }

        private void CreateMemberbutton_Click(object sender, EventArgs e)
        {
            PersonModel p = new PersonModel();
            p.FirstName = FirstNameValue.Text;
            p.LastName = LastNameValue.Text;
            p.Email = Emailvalue.Text;
            p.Email = CellPhoneValue.Text;
            GlobalConfig.Connections.CreatePerson(p);


        }

        private void Create_Team_Load(object sender, EventArgs e)
        {

        }
    }
}
