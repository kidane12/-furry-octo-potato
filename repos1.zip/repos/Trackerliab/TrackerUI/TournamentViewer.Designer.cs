﻿namespace TrackerUI
{
    partial class TournamentViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HeadLabel = new System.Windows.Forms.Label();
            this.TornamentName = new System.Windows.Forms.Label();
            this.Roundlabel = new System.Windows.Forms.Label();
            this.roundDropdown = new System.Windows.Forms.ComboBox();
            this.UnplayedcheckBox = new System.Windows.Forms.CheckBox();
            this.MatchuplistBox = new System.Windows.Forms.ListBox();
            this.TeamOneName = new System.Windows.Forms.Label();
            this.TeamOneScoreLabel = new System.Windows.Forms.Label();
            this.ScoretextBox = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.ScoreTwolabel = new System.Windows.Forms.Label();
            this.TeamTwoname = new System.Windows.Forms.Label();
            this.Scorebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // HeadLabel
            // 
            this.HeadLabel.AutoSize = true;
            this.HeadLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HeadLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.HeadLabel.Location = new System.Drawing.Point(12, 9);
            this.HeadLabel.Name = "HeadLabel";
            this.HeadLabel.Size = new System.Drawing.Size(219, 42);
            this.HeadLabel.TabIndex = 0;
            this.HeadLabel.Text = "Tournament";
            this.HeadLabel.Click += new System.EventHandler(this.Label1_Click);
            // 
            // TornamentName
            // 
            this.TornamentName.AutoSize = true;
            this.TornamentName.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TornamentName.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.TornamentName.Location = new System.Drawing.Point(237, 9);
            this.TornamentName.Name = "TornamentName";
            this.TornamentName.Size = new System.Drawing.Size(116, 42);
            this.TornamentName.TabIndex = 1;
            this.TornamentName.Text = "Nlone";
            this.TornamentName.Click += new System.EventHandler(this.Label1_Click_1);
            // 
            // Roundlabel
            // 
            this.Roundlabel.AutoSize = true;
            this.Roundlabel.Location = new System.Drawing.Point(19, 74);
            this.Roundlabel.Name = "Roundlabel";
            this.Roundlabel.Size = new System.Drawing.Size(75, 25);
            this.Roundlabel.TabIndex = 2;
            this.Roundlabel.Text = "Round";
            this.Roundlabel.Click += new System.EventHandler(this.Roundlabel_Click);
            // 
            // roundDropdown
            // 
            this.roundDropdown.FormattingEnabled = true;
            this.roundDropdown.Location = new System.Drawing.Point(111, 77);
            this.roundDropdown.Name = "roundDropdown";
            this.roundDropdown.Size = new System.Drawing.Size(227, 33);
            this.roundDropdown.TabIndex = 3;
            // 
            // UnplayedcheckBox
            // 
            this.UnplayedcheckBox.AutoSize = true;
            this.UnplayedcheckBox.Location = new System.Drawing.Point(111, 129);
            this.UnplayedcheckBox.Name = "UnplayedcheckBox";
            this.UnplayedcheckBox.Size = new System.Drawing.Size(122, 29);
            this.UnplayedcheckBox.TabIndex = 4;
            this.UnplayedcheckBox.Text = "Unplayed";
            this.UnplayedcheckBox.UseVisualStyleBackColor = true;
            // 
            // MatchuplistBox
            // 
            this.MatchuplistBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MatchuplistBox.FormattingEnabled = true;
            this.MatchuplistBox.ItemHeight = 25;
            this.MatchuplistBox.Location = new System.Drawing.Point(24, 173);
            this.MatchuplistBox.Name = "MatchuplistBox";
            this.MatchuplistBox.Size = new System.Drawing.Size(314, 202);
            this.MatchuplistBox.TabIndex = 5;
            // 
            // TeamOneName
            // 
            this.TeamOneName.AutoSize = true;
            this.TeamOneName.Location = new System.Drawing.Point(344, 173);
            this.TeamOneName.Name = "TeamOneName";
            this.TeamOneName.Size = new System.Drawing.Size(108, 25);
            this.TeamOneName.TabIndex = 6;
            this.TeamOneName.Text = "Team one";
            this.TeamOneName.Click += new System.EventHandler(this.Label1_Click_2);
            // 
            // TeamOneScoreLabel
            // 
            this.TeamOneScoreLabel.AutoSize = true;
            this.TeamOneScoreLabel.Location = new System.Drawing.Point(344, 234);
            this.TeamOneScoreLabel.Name = "TeamOneScoreLabel";
            this.TeamOneScoreLabel.Size = new System.Drawing.Size(68, 25);
            this.TeamOneScoreLabel.TabIndex = 7;
            this.TeamOneScoreLabel.Text = "Score";
            // 
            // ScoretextBox
            // 
            this.ScoretextBox.Location = new System.Drawing.Point(430, 231);
            this.ScoretextBox.Name = "ScoretextBox";
            this.ScoretextBox.Size = new System.Drawing.Size(100, 31);
            this.ScoretextBox.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(430, 360);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 31);
            this.textBox2.TabIndex = 11;
            // 
            // ScoreTwolabel
            // 
            this.ScoreTwolabel.AutoSize = true;
            this.ScoreTwolabel.Location = new System.Drawing.Point(344, 363);
            this.ScoreTwolabel.Name = "ScoreTwolabel";
            this.ScoreTwolabel.Size = new System.Drawing.Size(68, 25);
            this.ScoreTwolabel.TabIndex = 10;
            this.ScoreTwolabel.Text = "Score";
            // 
            // TeamTwoname
            // 
            this.TeamTwoname.AutoSize = true;
            this.TeamTwoname.Location = new System.Drawing.Point(344, 302);
            this.TeamTwoname.Name = "TeamTwoname";
            this.TeamTwoname.Size = new System.Drawing.Size(105, 25);
            this.TeamTwoname.TabIndex = 9;
            this.TeamTwoname.Text = "Team two";
            // 
            // Scorebutton
            // 
            this.Scorebutton.Location = new System.Drawing.Point(405, 117);
            this.Scorebutton.Name = "Scorebutton";
            this.Scorebutton.Size = new System.Drawing.Size(89, 41);
            this.Scorebutton.TabIndex = 12;
            this.Scorebutton.Text = "Score";
            this.Scorebutton.UseVisualStyleBackColor = true;
            // 
            // TournamentViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(542, 479);
            this.Controls.Add(this.Scorebutton);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.ScoreTwolabel);
            this.Controls.Add(this.TeamTwoname);
            this.Controls.Add(this.ScoretextBox);
            this.Controls.Add(this.TeamOneScoreLabel);
            this.Controls.Add(this.TeamOneName);
            this.Controls.Add(this.MatchuplistBox);
            this.Controls.Add(this.UnplayedcheckBox);
            this.Controls.Add(this.roundDropdown);
            this.Controls.Add(this.Roundlabel);
            this.Controls.Add(this.TornamentName);
            this.Controls.Add(this.HeadLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "TournamentViewer";
            this.Text = "TournamentViewer";
            this.Load += new System.EventHandler(this.TournamentViewer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HeadLabel;
        private System.Windows.Forms.Label TornamentName;
        private System.Windows.Forms.Label Roundlabel;
        private System.Windows.Forms.ComboBox roundDropdown;
        private System.Windows.Forms.CheckBox UnplayedcheckBox;
        private System.Windows.Forms.ListBox MatchuplistBox;
        private System.Windows.Forms.Label TeamOneName;
        private System.Windows.Forms.Label TeamOneScoreLabel;
        private System.Windows.Forms.TextBox ScoretextBox;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label ScoreTwolabel;
        private System.Windows.Forms.Label TeamTwoname;
        private System.Windows.Forms.Button Scorebutton;
    }
}

