﻿using System.Collections.Generic;

namespace Trackerliab
{
    public class MatchupModel
    {
        public List<MatchupEntryModel> Entries { get; set; } = new List<MatchupEntryModel>();
        public Teammodel Winner { get; set; }
        public int Matchupround { get; set; }
    }
}