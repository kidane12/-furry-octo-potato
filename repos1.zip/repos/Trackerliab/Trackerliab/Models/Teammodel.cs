﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trackerliab
{
   public class Teammodel
    {
        public List<PersonModel> Teammembers { get; set; } = new List<PersonModel>();
        public string TeamName { get; set; }
    }
}
