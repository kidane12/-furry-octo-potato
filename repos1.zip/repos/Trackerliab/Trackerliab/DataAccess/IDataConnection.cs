﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trackerliab
{
    public interface IDataConnection
    {
        PrizeModel createPrize(PrizeModel model);
        PersonModel CreatePerson(PersonModel p);
    }
}
