﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trackerliab
{
    public class TextConnector : IDataConnection
    {
        public PersonModel CreatePerson(PersonModel p)
        {
            throw new NotImplementedException();
        }

        public PrizeModel createPrize(PrizeModel model)
        {
            model.Id=1;
            return model;

        }
    }
}
