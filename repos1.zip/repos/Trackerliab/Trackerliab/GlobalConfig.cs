﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trackerliab
{
   public static class GlobalConfig
    {
        public static IDataConnection Connections { get; private set; }
        public static void InitializeConnections(Databasetype db)
        {
            if (db==Databasetype.sql)
            {
                //SQL
                SQLconnector sql = new SQLconnector();
                Connections =sql;

            }
            if (db==Databasetype.textfile)
            {
                //Text
                TextConnector text = new TextConnector();
                Connections=text;
            }
            }
       
    }
}
