﻿using Anon.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace PCMtest
{
    public class PCMXMLobjtest
    {
        Declass d = new Declass();
        [Fact]
        public void Attributes_Properly_Parsed_ZeroHasBounds()
        {
            foreach (var e in d.speakerModel.AttributeTypes.ToList())
            {
                if (e.HasBounds == "0")
                {
                    /*foreach (var x in e.EcResBoundedAttributeTypeValue.ToList())
                    {
                        Console.WriteLine(x.Lower);
                        Console.WriteLine(x.Upper);
                    }*/
                    Assert.Null(e.EcoResBoundedAttributeTypeValue);
                }
            }
        }
        [Fact]
        public void Attributes_Properly_Parsed_HasBounds()
        {
            foreach (var e in d.speakerModel.AttributeTypes.ToList())
            {
                if (e.HasBounds == "1")
                {
                    Assert.NotNull(e.EcoResBoundedAttributeTypeValue);
                    //Assert.Equal(1,e.EcoResBoundedAttributeTypeValue.ToList().Count());
                }
            }
        }
        [Fact]
        public void Components_Properly_Parsed()
        {
        }

        [Fact]
        public void ExportPCProductConfigurationModel_Properly_Parsed()
        {
        }

        [Fact]
        public void TableConstraintDefintions_Properly_Parsed()
        {
        }


    }
}
